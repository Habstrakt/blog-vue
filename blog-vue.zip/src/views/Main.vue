<script>
import axios from "axios";
import Spinner from "@/components/Spinner.vue";
import Pagination from "@/components/Pagination.vue";
import Aside from "@/components/Aside.vue";
export default {
  data() {
    return {
      posts: [],
      currentPage: 1,
      postsPerPage: 20,
      showScrollBtn: false,
    };
  },
  components: {
    Spinner,
    Pagination,
    Aside,
  },
  methods: {
    async getPosts() {
      try {
        const response = await axios.get(
          "http://blog.test/wp-json/wp/v2/posts"
        );
        this.posts = response.data;
      } catch (error) {
        console.error(error);
      }
    },
    scrollBtn() {
      const scrollDuration = 800;
      const scrollStep = -window.pageYOffset / (scrollDuration / 15);
      let scrollInterval = setInterval(() => {
        if (window.pageYOffset !== 0) {
          window.scrollBy(0, scrollStep);
        } else {
          clearInterval(scrollInterval);
        }
      }, 15);
    },
    handleScroll() {
      if (window.pageYOffset > 1000) {
        this.showScrollBtn = true;
      } else {
        this.showScrollBtn = false;
      }
    },
    nextPage() {
      this.currentPage++;
      this.scrollBtn();
    },
    prevPage() {
      this.currentPage--;
      this.scrollBtn();
    },
  },
  mounted() {
    this.getPosts();
    window.addEventListener("scroll", this.handleScroll);
  },
  unmounted() {
    window.removeEventListener("scroll", this.handleScroll);
  },
  computed: {
    totalPages() {
      console.log(Math.ceil(this.posts.length / this.postsPerPage));
      return Math.ceil(this.posts.length / this.postsPerPage);
    },
    displayedPosts() {
      const startIndex = (this.currentPage - 1) * this.postsPerPage;
      const endIndex = startIndex + this.postsPerPage;
      return this.posts.slice(startIndex, endIndex);
    },
  },
};
</script>

<template>
  <div class="container">
    <div class="row">
      <Aside />
      <div class="col-lg-9">
        <main>
          <section>
            <template v-if="posts.length > 0">
              <article v-for="post in displayedPosts" :key="post.id">
                <h3>
                  <router-link
                    class="text_title"
                    :to="{ name: 'post', params: { id: post.id } }"
                  >
                    {{ post.title.rendered }}
                  </router-link>
                </h3>
                <div v-html="post.content.rendered" class="text"></div>
                <p class="date">{{ post.formatted_date }}</p>
              </article>
            </template>
            <template v-else>
              <Spinner />
            </template>
          </section>
        </main>
        <div v-if="showScrollBtn" @click="scrollBtn" class="btn btn-secondary">
          <img src="../assets/img/arrow-up.svg" alt="" />
        </div>
        <div class="pagination justify-content-end">
          <button
            class="btn btn-primary"
            v-if="currentPage < totalPages"
            @click="nextPage"
          >
            Next
          </button>
          <button
            class="btn btn-primary"
            v-if="currentPage > 1"
            @click="prevPage"
          >
            Preview
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
main {
  margin-top: 21px;
}
h3 {
  text-align: center;
  margin-bottom: 30px;
}
.date {
  text-align: end;
}
.text {
  font-size: 1.2rem;
  text-align: center;
}
article {
  padding: 50px;
  background-color: white;
  margin-top: 14px;
}
.text_title {
  color: black;
  text-decoration: none;
}
.text_title:hover {
  color: rgb(168, 12, 77);
}
ul {
  list-style-type: none;
}
.pagination {
  margin: 20px 0;
}
.btn-secondary {
  position: fixed;
  bottom: 100px;
  right: 60px;
}
</style>
