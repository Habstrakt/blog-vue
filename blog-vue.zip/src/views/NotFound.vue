<template>
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2 class="not_found">Страница не найдена</h2>
      </div>
    </div>
  </div>
</template>

<style>
.not_found {
  margin-top: 21px;
  text-align: center;
}
</style>
