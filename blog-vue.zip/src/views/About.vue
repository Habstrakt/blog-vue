<template>
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="about-block">about block</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.about-block {
  padding: 50px;
  background-color: white;
  margin-top: 21px;
}
</style>
