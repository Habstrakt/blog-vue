<template>
  <div class="col-lg-3">
    <aside>
      <img src="../assets/img/avatar.jpg" alt="" />
      <div>
        <p>Repository and contacts</p>
        <a href="https://github.com/Habstrakt"
          ><img
            class="github-logo"
            src="../assets/img/github_icon.svg"
            alt=""
          />
        </a>
      </div>
    </aside>
  </div>
</template>

<style scoped>
aside {
  padding: 20px;
  background-color: white;
  margin-top: 21px;
}
img {
  display: block;
  margin: 0 auto;
}
p {
  margin-top: 10px;
  text-align: center;
}
.github-logo {
  width: 30px;
  padding-right: 5px;
}
</style>
