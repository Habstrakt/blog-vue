<template>
  <div class="pagination">
    <button>Next</button>
    <button>Preview</button>
  </div>
</template>


